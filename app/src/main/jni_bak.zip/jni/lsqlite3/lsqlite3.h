/*
**
*/

#ifndef __LUA_SQLITE3_H_
#define __LUA_SQLITE3_H_

int luaopen_lsqlite3(lua_State *L);

#endif
